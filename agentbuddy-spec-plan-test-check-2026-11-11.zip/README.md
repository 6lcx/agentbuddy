# AgentBuddy Spec / Plan / Test / Check 文档包

本包保存项目现有开发文档的原文件快照，保留仓库目录结构。没有把历史结果重写成最新验收结论。

## 阅读顺序

1. Spec：`docs/specs/platform.md` 是当前规格；同目录的早期版本、评审及 archive 为历史资料。
2. Plan：根目录 `plan.md` 为主计划，`docs/plans/` 为阶段实施计划。
3. Test / Check：`docs/validation/` 保存测试与验收记录；两者在阶段文档中合并记录，并非独立的 test.md、check.md。最近发布检查见 `docs/validation/release-v0.1.0.md`，指标实测见 `docs/validation/agent-metrics-baseline.md`。
4. 开发流程 Skill：`.agents/skills/agentbuddy-development/SKILL.md` 及 references 说明如何执行该流程。

## 补充资料

同时收录 docs 下的设计、调研、部署、发布说明与架构待办，便于理解决策背景。`manifest.json` 提供每个原文件的字节数与 SHA256，可验证内容与打包时的原文件一致。

本包是文档集合，不是可独立执行的程序或测试工程。文档引用的源码、测试脚本、锁文件仍需从仓库获取；截图、模型凭据、数据库、聊天压缩包和 data 下的原始运行证据不包含在此包中。历史文件中的本地路径或链接可能仅在原环境可用。各阶段的通过、未执行、失败和待验证记录按当时状态保留。
